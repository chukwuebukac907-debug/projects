# LUXESTATE — Premium Real Estate Website

> *Nigeria's Premier Luxury Land & Property Platform*

---

## 👥 Project Credits

| Name | Registration Number |
|------|-------------------|
| **Chuks Chukwuebuka Arthur** | MD/23/1567 |
| **Nosike Ibeawuchi Jonathan** | MD/23/1567 |

---

## 📁 Project Structure

```
luxestate/
├── index.html          ← Home Page (Netflix-style)
├── properties.html     ← Property Listings & Search
├── dashboard.html      ← Agent / User Dashboard
└── README.md           ← This file
```

---

## 🌐 Pages Overview

### 1. `index.html` — Home Page
Modelled after the Netflix interface with:
- **Translucent navbar** that solidifies on scroll
- **Full-viewport hero section** with featured property overlay, stats, and CTA buttons
- **5 horizontally scrollable property rows** (Featured Estates, Premium Land Plots, Luxury Villas, Commercial Properties, New to Market)
- **Interactive property cards** with hover-reveal animations showing details and action buttons
- **Mid-page featured banner** with investment call-to-action
- **Statistics bar** (4,200+ listings, ₦280B portfolio, 12,000+ clients, 18 cities, 97% satisfaction)
- **Testimonials section** (3 client reviews)
- **Fully structured footer** with company info, links, and contact details

### 2. `properties.html` — Property Listings
Full property browse experience featuring:
- **Hero search bar** with location and type filters
- **Quick-tag filter buttons** for rapid category switching
- **Sidebar filter panel** (Property Type, Price Range slider, Location checkboxes, Bedrooms, Features)
- **18 property cards** in a responsive grid layout
- **Toggle between Grid and List views**
- **Sort options** (Relevance, Price Low/High, Newest, Area)
- **Property detail modal** with full specifications, features checklist, and action buttons (Schedule Inspection, Save, Call Agent)
- **Pagination system**

### 3. `dashboard.html` — Agent Dashboard
Elite management dashboard with:
- **Fixed sidebar navigation** with icon labels, section groups, and notification badges
- **Topbar** with search, notifications bell, and messages
- **Welcome banner** with date/time greeting and quick action buttons
- **4 animated KPI cards** (Total Listings, Portfolio Value, Active Inquiries, Properties Sold — with trend indicators)
- **Revenue bar chart** (monthly data for 2024 with ₦42.8B total)
- **Property mix donut chart** (SVG-rendered, by category)
- **Quick action buttons** (Add Listing, Schedule Inspection, Upload Documents, Generate Report)
- **Recent Transactions table** with property thumbnails, prices, and status badges
- **Activity feed** with timestamped events
- **Saved Properties** section (removable cards)
- **Calendar widget** with event markers and upcoming inspections
- **Agent Profile card** with performance stats
- **Slide-in Notification panel** (7 notifications)

---

## 🎨 Design System

### Colour Palette
| Token | Hex | Usage |
|-------|-----|-------|
| Background Primary | `#050810` | Page background |
| Background Secondary | `#0B1018` | Sidebar, hero sections |
| Card | `#111928` | Property cards, panels |
| Gold (Primary Accent) | `#C9A84C` | CTAs, highlights, prices |
| Gold Light | `#E5CC7A` | Hover states |
| Gold Dark | `#8B6E2A` | Gradient endpoints |
| White | `#FFFFFF` | Primary text |
| Off-White | `#CBD5E1` | Secondary text |
| Muted | `#64748B` | Labels, metadata |
| Red | `#E50914` | HOT badges |
| Green | `#22C55E` | Available status, KPI ups |
| Blue | `#3B82F6` | Inquiry KPI |
| Purple | `#A855F7` | Sales KPI |

### Typography
| Role | Font | Weights |
|------|------|---------|
| Display / Headings | Playfair Display (Serif) | 400, 600, 700, 900 |
| Body / UI | Inter (Sans-serif) | 300, 400, 500, 600 |
| Labels / Badges / Nav | Montserrat (Sans-serif) | 400, 500, 600, 700, 800 |

### Signature Design Element
The **gold-on-black luxury palette** combined with the **Netflix-style horizontal scroll rows** — each property card uses a dual-state design (minimal image thumbnail at rest → expanded overlay with specs and actions on hover), creating a cinematic browsing experience for real estate.

---

## ⚙️ Technologies Used

- **HTML5** — Semantic markup
- **CSS3** — Custom properties, Grid, Flexbox, animations, transitions
- **Vanilla JavaScript** — DOM manipulation, filtering, pagination, chart rendering
- **Google Fonts** — Playfair Display, Inter, Montserrat
- **Unsplash API** — High-quality property photography (no API key required)
- **SVG** — Donut chart rendered in pure SVG

---

## 🚀 How to Run

1. Download or clone this project folder
2. Open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari)
3. Navigate between pages using the navbar links:
   - **Home** → `index.html`
   - **Properties** → `properties.html`
   - **Dashboard** → `dashboard.html`

> **No server, build tool, or internet connection required** (except for loading Google Fonts and Unsplash images).

---

## 📱 Responsive Design

All three pages are responsive and tested at:
- **Desktop** (1440px+) — Full layout
- **Laptop** (1024px–1440px) — Adjusted grid columns
- **Tablet** (768px–1024px) — Stacked sidebar, 2-column grids
- **Mobile** (< 768px) — Single column, hidden nav links

---

## 🏢 About LUXESTATE (Fictional Company)

> **LUXESTATE Nigeria Ltd**  
> 15 Bourdillon Road, Ikoyi, Lagos  
> Tel: +234 (0) 701 234 5678  
> Email: hello@luxestate.ng  
> RC: 1234567  

*LUXESTATE is a fictional company created for academic/project purposes. All property listings, prices, and client details shown are illustrative and do not represent real transactions.*

---

*© 2024 LUXESTATE — Academic Project. All rights reserved.*
